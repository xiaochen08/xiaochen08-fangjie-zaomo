# WorkBuddy 导入

请把下面四个 ZIP 全部导入，不能只导入主技能或其中一个工坊：

1. `fjzm-workbuddy-v5.2.0.zip`
2. `fjzm-model-workbuddy-v5.2.0.zip`
3. `fjzm-texture-workbuddy-v5.2.0.zip`
4. `fjzm-animation-workbuddy-v5.2.0.zip`

每个 ZIP 根目录均包含 `SKILL.md`。四个技能共同使用 ContractFlow v1；缺少任意一个时，对应生产阶段会停止。
